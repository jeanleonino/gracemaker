module.exports = {
  'facebookAuth':{
    'clientID':'1825483904332763',
    'clientSecret':'665ab0405d2ddb924c231726b8b16a5c',
    'callbackURL':'http://localhost:3000/auth/facebook/callback'
  }
}
